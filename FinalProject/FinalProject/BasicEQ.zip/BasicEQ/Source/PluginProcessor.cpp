/*
  ==============================================================================
This file contains the basic framework code for a JUCE plugin processor.
 
 <Work Credit>
 Matkatmusic GitHub - matkatmusic/SimpleEQ: The code for the SimpleEQ C++ Plugin Project (https://github.com/matkatmusic/SimpleEQ.)
 

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"



//==============================================================================
BasicEQAudioProcessor::BasicEQAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#endif
{
}

BasicEQAudioProcessor::~BasicEQAudioProcessor()
{
}

//==============================================================================
// Returns the name of the plugin
const juce::String BasicEQAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

// Indicates whether the plugin accepts MIDI input
bool BasicEQAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

// Indicates whether the plugin produces MIDI output
bool BasicEQAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

// Indicates whether the plugin is a MIDI effect
bool BasicEQAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

// Returns the tail length in seconds
double BasicEQAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}
// Returns the number of programs (presets)
int BasicEQAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}
// Returns the index of the currently selected program
int BasicEQAudioProcessor::getCurrentProgram()
{
    return 0;
}
// Sets the currently selected program by index
void BasicEQAudioProcessor::setCurrentProgram (int index)
{
}
// Returns the name of the program at the specified index
const juce::String BasicEQAudioProcessor::getProgramName (int index)
{
    return {};
}
// Changes the name of the program at the specified index
void BasicEQAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
// Prepares the plugin to play audio
void BasicEQAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
    
    juce::dsp::ProcessSpec spec;
    spec.maximumBlockSize = samplesPerBlock;
    spec.numChannels = 1;
    spec.sampleRate = sampleRate;
    
    leftChain.prepare(spec);
    rightChain.prepare(spec);
    
    updateFilters();
}
    
    

// Releases resources when playback stops
void BasicEQAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
// Checks if the plugin supports the specified channel layouts
bool BasicEQAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

 
// Audio processing function that applies the EQ filters to the input buffer
void BasicEQAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
    
    updateFilters();
    
                  
    
    juce::dsp::AudioBlock<float> block(buffer);
    
    auto leftBlock = block.getSingleChannelBlock(0);
    auto rightBlock = block.getSingleChannelBlock(1);
    
    juce::dsp::ProcessContextReplacing<float> leftContext(leftBlock);
    juce::dsp::ProcessContextReplacing<float> rightContext(rightBlock);
    
    leftChain.process(leftContext);
    rightChain.process(rightContext);
}



//==============================================================================
// Checks if the plugin has an editor
bool BasicEQAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* BasicEQAudioProcessor::createEditor()
{
    //return new BasicEQAudioProcessorEditor (*this);
    return new juce::GenericAudioProcessorEditor(*this);
}

//==============================================================================
// Stores the plugin's state in a memory block
void BasicEQAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void BasicEQAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//Function to retrieve audio processing chain settings from the AudioProcessorValueTreeState.
    ChainSettings getChainSettings(juce::AudioProcessorValueTreeState& apvts)
{
        ChainSettings settings;
        // Load values from the AudioProcessorValueTreeState for each parameter
        settings.lowCutFreq = apvts.getRawParameterValue("LowCut Freq")->load();
        settings.highCutFreq = apvts.getRawParameterValue("HighCut Freq")->load();
        settings.peakFreq = apvts.getRawParameterValue("Peak Freq")->load();
        settings.peakGainDecibels = apvts.getRawParameterValue("Peak Gain")->load();
        settings.peakQuality = apvts.getRawParameterValue("Peak Quality")->load();
        // Cast slope values to the appropriate enumeration type
        settings.lowCutSlope = static_cast<Slope>(apvts.getRawParameterValue("LowCut Slope")->load());
        settings.highCutSlope = static_cast<Slope>(apvts.getRawParameterValue("HighCut Slope")->load());
        
        
        return settings;
    }

//Function to update the peak filter coefficients based on the provided ChainSettings.
void BasicEQAudioProcessor::updatePeakFilter(const ChainSettings &ChainSettings)
{
    auto peakCoefficients = juce::dsp::IIR::Coefficients<float>::makePeakFilter(getSampleRate(),ChainSettings.peakFreq, ChainSettings.peakQuality, juce::Decibels::decibelsToGain(ChainSettings.peakGainDecibels));
    
    updateCoefficients(leftChain.get<ChainPositions::Peak>().coefficients, peakCoefficients);
    updateCoefficients(rightChain.get<ChainPositions::Peak>().coefficients, peakCoefficients);
    
}

    //Function to update filter coefficients by copying values from the replacements to the old coefficients.
    void BasicEQAudioProcessor::updateCoefficients(Coefficients &old, const Coefficients &replacements)
{
        *old = *replacements;
    }

//Function to update low-cut filters based on the provided ChainSettings.
void BasicEQAudioProcessor::updatelowCutFilters(const ChainSettings &chainSettings)
    {
        auto lowCutCoefficients = juce::dsp::FilterDesign<float>::designIIRHighpassHighOrderButterworthMethod(chainSettings.lowCutFreq, getSampleRate(), 2*(chainSettings.lowCutSlope +1));
        auto& leftLowCut = leftChain.get<ChainPositions::LowCut>();
        auto& rightLowCut = rightChain.get<ChainPositions::LowCut>();
    
    //Function to update coefficients for both left and right low-cut filters
    updateCutFilter<CutFilter, juce::ReferenceCountedArray<juce::dsp::IIR::Coefficients<float>>>(rightLowCut, lowCutCoefficients, (Slope) chainSettings.lowCutSlope);
    updateCutFilter<CutFilter, juce::ReferenceCountedArray<juce::dsp::IIR::Coefficients<float>>>(leftLowCut, lowCutCoefficients, (Slope) chainSettings.lowCutSlope);
        
    }
//Function to update high-cut filters based on the provided ChainSettings.
void BasicEQAudioProcessor::updatehighCutFilters(const ChainSettings &chainSettings)
{
    auto highCutCoefficients = juce::dsp::FilterDesign<float>::designIIRHighpassHighOrderButterworthMethod(chainSettings.highCutFreq, getSampleRate(), 2*(chainSettings.highCutSlope +1));
    auto& leftHighCut = leftChain.get<ChainPositions::HighCut>();
    auto& rightHighCut = rightChain.get<ChainPositions::HighCut>();
    
    //Function to update coefficients for both left and right high-cut filters
    updateCutFilter<CutFilter, juce::ReferenceCountedArray<juce::dsp::IIR::Coefficients<float>>>(rightHighCut, highCutCoefficients, (Slope) chainSettings.highCutSlope);
    updateCutFilter<CutFilter, juce::ReferenceCountedArray<juce::dsp::IIR::Coefficients<float>>>(leftHighCut, highCutCoefficients, (Slope) chainSettings.highCutSlope);
}

//update all filters by retrieving ChainSettings and updating low-cut, high-cut, and peak filters accordingly.
void BasicEQAudioProcessor::updateFilters()
    {
        auto chainSettings = getChainSettings(apvts);
        // Update low-cut filters
        updatelowCutFilters(chainSettings);
        // Update high-cut filters
        updatehighCutFilters(chainSettings);
        // Update peak filter
        updatePeakFilter(chainSettings);
    }

// Define and add parameters to the AudioProcessorValueTreeState's parameter layout.
juce::AudioProcessorValueTreeState::ParameterLayout BasicEQAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    
    // Adding parameters for LowCut frequency, HighCut frequency, Peak frequency, Peak gain, and Peak quality
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("LowCut Freq", 1), "LowCut Freq",
                                                           juce::NormalisableRange<float>(20.f, 20000.f, 1.f, 1.f), 1.f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("HighCut Freq", 1), "HighCut Freq",
                                                           juce::NormalisableRange<float>(20.f, 20000.f, 1.f, 1.f), 1.f));
    
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("Peak Freq", 1), "Peak Freq", 
                                                           juce::NormalisableRange<float>(20.f, 20000.f, 0.5f, 1.f), 0.25f));
    
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("Peak Gain", 1), "Peak Gain", 
                                                           juce::NormalisableRange<float>(-24.f, 24.f, 0.5f, 1.f), 1.f));
 
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("Peak Quality", 1), "Peak Quality", 
                                                           juce::NormalisableRange<float>(0.1f, 10.f, 0.05f, 1.f), 1.f));

    // Creating a StringArray for slope choices in decibels per octave.
    juce::StringArray stringArray;
    for (int i = 0; i < 4; ++i)
    {
        juce::String str;
        str << (12 + i * 12);
        str << " db / Oct";
        stringArray.add(str);
    }
    
    // Adding parameters for LowCut Slope and HighCut Slope as choice parameters.
    layout.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID( "LowCut Slope", 1), "LowCut Slope", stringArray, 0));
    layout.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID( "HighCut Slope", 1), "HighCut Slope", stringArray, 0));

    return layout;
}

    
//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new BasicEQAudioProcessor();
};
